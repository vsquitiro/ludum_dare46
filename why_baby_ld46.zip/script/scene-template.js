/** @type {import("../typings/phaser")} */

import globalConfig from './global-config.js';
import SystemState from './state-machine.js';

class MenuScene extends Phaser.Scene {
    create() {
        
    }
    update(time, delta) {
        
    }
}

export default MenuScene;